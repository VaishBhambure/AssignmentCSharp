﻿namespace ArtExhibition.Identity
{
    public class Class1
    {

    }
}
