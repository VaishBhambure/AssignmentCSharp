﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArtExhibition.Domain.Model
{
    public class Artist
    {
        [Key]
        public int ArtistID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public DateTime BirthDate { get; set; }

        public string Phone { get; set; }

        public string UserID { get; set; }
        public User User { get; set; }

        public ICollection<Gallery> Galleries { get; set; }
        public ICollection<Artwork> Artworks { get; set; }
    }
}
